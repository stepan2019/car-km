<?php /* Smarty version 3.1.24, created on 2019-09-03 16:17:36
         compiled from "E:/workspace/carpass/admin/templates/default/footer.html" */ ?>
<?php
/*%%SmartyHeaderCode:13139061145d6e9220a53362_26048443%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd6cf64460694aca09ad4c2ec1379dc4cbaaa0e9b' => 
    array (
      0 => 'E:/workspace/carpass/admin/templates/default/footer.html',
      1 => 1567332163,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13139061145d6e9220a53362_26048443',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_5d6e9220a74fd1_27270655',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d6e9220a74fd1_27270655')) {
function content_5d6e9220a74fd1_27270655 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '13139061145d6e9220a53362_26048443';
?>
</div> 

<div id="footer">
		<div class="lfloat">Copyright &copy; 2018 OxyClassifieds.com</div>

		<div class="rfloat"><a href="http://www.oxyclassifieds.com/contact.html" target="_blank">Contact</a></div>
</div>	

</div> 

</body>
</html>

<?php }
}
?>
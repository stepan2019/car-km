<?php
	define ("LAST_DAY","06");
?>

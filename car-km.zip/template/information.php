<div class="modal fade" id="history-1" tabindex="-1" role="dialog" aria-labelledby="modalTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h5 class="modal-title" id="modalTitle">National Car Pass Information</h5>
            </div>
            <div class="modal-body">
                <p><?php echo $information['content']; ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary submit-fs btn-custom" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
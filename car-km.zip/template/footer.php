<footer>
    <div class="container">
     <!--   <div class="row">-->
     <!--       <div class="col-md-3 col-sm-4">-->
     <!--           <ul>-->
     <!--               <li><a href="https://www.car-km.com">Home</a></li>-->
     <!--               <li><a href="https://www.car-km.com/template/info.php">Information</a></li>-->
     <!--           </ul>-->
     <!--       </div>-->
     <!--       <div class="col-md-3 col-sm-4">-->
     <!--           <ul>-->
     <!--               <li><a href="https://www.car-km.com/vehicle/add.php">Add Vehicle Km</a></li>-->
     <!--               <li><a href="https://www.car-km.com/template/price.php">Price</a></li>-->
     <!--           </ul>-->
     <!--       </div>-->
     <!--       <div class="col-md-3 col-sm-4">-->
     <!--           <ul>-->
     <!--               <li><a href="/template/privacy.php">Privacy Policy</a></li>-->
     <!--               <li><a href="/template/terms.php">Term and Services</a></li>-->
					<!--<img src='../img/QR-Carpass.png' alt='QR Carpass' />-->
     <!--               <li><div class="fb-like" data-href="https://developers.facebook.com/docs/plugins/" data-width="" data-layout="button" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div></li>-->
     <!--           </ul>-->
     <!--       </div>-->
     <!--       <div class="col-md-3 col-sm-12">-->
     <!--           <h2>Contact</h2>-->
     <!--           <ul>-->
     <!--               <li><a href="https://goo.gl/maps/JUuKZsggS7QXHvQM7"target="_blank"><i class="fa fa-home"></i> Athens, Greece</a></li>-->
     <!--               <li><a href="tel:6983442786"><i class="fa fa-phone"></i>+30 698 344 2786</a></li>-->
     <!--               <li><a href="template/contact.php"><i class="fa fa-envelope"></i> car-km.com@gmail.com</a></li>-->
     <!--               <li><a href="index.php"><i class="fa fa-globe"></i> https://www.car-km.com</a></li>-->
     <!--           </ul>-->
     <!--       </div>-->
     <!--   </div>-->
     <!--   <div class="row copy-footer">-->
     <!--       <div class="col-sm-6 col-md-3">Copyright &copy;<script type="text/javascript">document.write(new Date().getFullYear());</script>-->
     <!--           <a target="_blank" rel="nofollow" href="https://car-km.com/"></a> car-km.com -->
     <!--       </div>-->
     <!--       <div class="col-sm-6 col-md-3 pull-right text-xs-right"><a href="https://realgreekhome.com"target="_blank">Created RealGreekhome.com</i></div>-->
     <!--   </div>-->
        
        
         <div class="row">
             <?php echo $footer_new['content1']; ?>
         </div>
         <div class="row copy-footer">
             <?php echo $footer_new['content2']; ?>
         </div>
    </div>
</footer>
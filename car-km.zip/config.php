<?php

	$config_db_server='localhost';

	$config_db_server_username='carkm_Fouad';

	$config_db_server_password='1?U}=aQ5U27M';

	$config_db_database='carkm_test';

	$config_db_charset='utf8';

	$config_db_collation='utf8_general_ci';

	$config_table_prefix='';

	$config_live_site='http://car-km.com';

	$config_abs_path='..';

	$config_demo=0;

	$config_debug=0;

	$config_data_set='general';

?>
